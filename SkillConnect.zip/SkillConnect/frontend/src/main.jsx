import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { getStoredToken } from './utils/auth';

import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Contacts from './pages/Contacts';
import Address from './pages/Address';
import Tasks from './pages/Tasks';
import ProtectedRoute from './components/ProtectedRoute';
import Navbar from './components/Navbar';
import ProtectedLayout from './components/ProtectedLayout';

getStoredToken();

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route
          path="/dashboard"
          element={
            <ProtectedLayout>
              <Dashboard />
            </ProtectedLayout>
          }
        />
        <Route
          path="/contacts"
          element={
            <ProtectedLayout>
              <Contacts />
            </ProtectedLayout>
          }
        />
        <Route
          path="/address"
          element={
            <ProtectedLayout>
              <Address />
            </ProtectedLayout>
          }
        />
        <Route
          path="/tasks"
          element={
            <ProtectedLayout>
              <Tasks />
            </ProtectedLayout>
          }
        />

        <Route path="*" element={<Login />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
