import { useEffect, useState } from 'react';
import client from '../api/axiosClient';

export default function Contacts() {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [contactNumber, setContactNumber] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [note, setNote] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Fetch contacts on page load
  const loadContacts = async () => {
    try {
      const res = await client.get('/contacts');
      setContacts(res.data);
    } catch (err) {
      console.error(err);
      setError('Failed to load contacts');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContacts();
  }, []);

  // Handle Add Contact
  const handleAddContact = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (contactNumber.length !== 10) {
      setError('Contact number must be 10 digits');
      return;
    }

    try {
      await client.post('/contacts', {
        contact_number: contactNumber,
        contact_email: contactEmail,
        note: note,
      });

      setSuccessMsg('Contact added successfully!');
      setContactNumber('');
      setContactEmail('');
      setNote('');

      loadContacts(); // reload after adding
    } catch (err) {
      console.error(err);
      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else {
        setError('Failed to add contact');
      }
    }
  };

  if (loading) return <p>Loading contacts...</p>;

  return (
    <div>
      <h1 style={{ marginBottom: '1rem' }}>Contacts</h1>

      {error && <p style={{ color: 'red', marginBottom: '1rem' }}>{error}</p>}
      {successMsg && <p style={{ color: 'lightgreen', marginBottom: '1rem' }}>{successMsg}</p>}

      {/* Add Contact Form */}
      <form onSubmit={handleAddContact} style={styles.form}>
        <input
          type="text"
          placeholder="Contact number (10 digits)"
          value={contactNumber}
          onChange={(e) => setContactNumber(e.target.value)}
          style={styles.input}
          required
        />

        <input
          type="email"
          placeholder="Contact email"
          value={contactEmail}
          onChange={(e) => setContactEmail(e.target.value)}
          style={styles.input}
        />

        <textarea
          placeholder="Note"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          style={styles.textarea}
        ></textarea>

        <button type="submit" style={styles.button}>Add Contact</button>
      </form>

      <hr style={{ margin: '1.5rem 0' }} />

      {/* Contact List */}
      <h2 style={{ marginBottom: '1rem' }}>Your Contacts</h2>
      {contacts.length === 0 ? (
        <p>No contacts found</p>
      ) : (
        <ul style={styles.list}>
          {contacts.map((c) => (
            <li key={c.id} style={styles.listItem}>
              <strong>{c.contact_number}</strong>  
              <br />
              {c.contact_email && <span>{c.contact_email}</span>}
              <br />
              {c.note && <small>{c.note}</small>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

const styles = {
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem',
    maxWidth: '350px',
  },
  input: {
    padding: '0.5rem',
    borderRadius: '6px',
    border: '1px solid #4b5563',
    background: '#0f172a',
    color: 'white',
  },
  textarea: {
    padding: '0.5rem',
    borderRadius: '6px',
    border: '1px solid #4b5563',
    background: '#0f172a',
    color: 'white',
  },
  button: {
    padding: '0.6rem',
    background: '#3b82f6',
    border: 'none',
    borderRadius: '6px',
    color: 'white',
    cursor: 'pointer',
  },
  list: {
    listStyle: 'none',
    padding: 0,
  },
  listItem: {
    background: '#1e293b',
    padding: '0.75rem',
    borderRadius: '8px',
    marginBottom: '0.75rem',
  },
};
