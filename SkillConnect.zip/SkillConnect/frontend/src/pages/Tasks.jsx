import { useEffect, useState } from 'react';
import client from '../api/axiosClient';

export default function Tasks() {
  const [contacts, setContacts] = useState([]);
  const [selectedContactId, setSelectedContactId] = useState('');

  const [tasks, setTasks] = useState([]);
  const [loadingContacts, setLoadingContacts] = useState(true);
  const [loadingTasks, setLoadingTasks] = useState(true);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState('pending');
  const [dueDate, setDueDate] = useState('');

  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // load contacts
  const loadContacts = async () => {
    try {
      const res = await client.get('/contacts');
      setContacts(res.data);
      if (res.data.length > 0) {
        setSelectedContactId(res.data[0].id.toString());
      }
    } catch (err) {
      console.error(err);
      setError('Failed to load contacts');
    } finally {
      setLoadingContacts(false);
    }
  };

  // load tasks
  const loadTasks = async () => {
    try {
      const res = await client.get('/tasks');
      setTasks(res.data);
    } catch (err) {
      console.error(err);
      setError('Failed to load tasks');
    } finally {
      setLoadingTasks(false);
    }
  };

  useEffect(() => {
    loadContacts();
    loadTasks();
  }, []);

  const handleAddTask = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!selectedContactId) {
      setError('Please select a contact');
      return;
    }
    if (!title.trim()) {
      setError('Title is required');
      return;
    }

    try {
      await client.post('/tasks', {
        contact_id: Number(selectedContactId),
        title,
        description,
        status,
        // convert from input datetime-local to "YYYY-MM-DD HH:mm:ss" if user filled it
        due_date: dueDate ? dueDate.replace('T', ' ') + ':00' : null,
      });

      setSuccessMsg('Task created successfully!');
      setTitle('');
      setDescription('');
      setStatus('pending');
      setDueDate('');

      loadTasks();
    } catch (err) {
      console.error(err);
      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else {
        setError('Failed to create task');
      }
    }
  };

  const formatDateTime = (value) => {
    if (!value) return 'N/A';
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleString();
  };

  if (loadingContacts || loadingTasks) {
    return <p>Loading tasks...</p>;
  }

  return (
    <div>
      <h1 style={{ marginBottom: '1rem' }}>Tasks</h1>

      {error && <p style={{ color: 'red', marginBottom: '1rem' }}>{error}</p>}
      {successMsg && <p style={{ color: 'lightgreen', marginBottom: '1rem' }}>{successMsg}</p>}

      {/* Select contact */}
      <div style={{ marginBottom: '1rem' }}>
        <label style={{ marginRight: '0.5rem' }}>Contact:</label>
        <select
          value={selectedContactId}
          onChange={(e) => setSelectedContactId(e.target.value)}
          style={styles.select}
        >
          {contacts.length === 0 && <option value="">No contacts available</option>}
          {contacts.map((c) => (
            <option key={c.id} value={c.id}>
              {c.contact_number} {c.contact_email ? `(${c.contact_email})` : ''}
            </option>
          ))}
        </select>
      </div>

      {/* Add Task Form */}
      <form onSubmit={handleAddTask} style={styles.form}>
        <input
          type="text"
          placeholder="Task title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          style={styles.input}
          required
        />
        <textarea
          placeholder="Task description (optional)"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          style={styles.textarea}
        ></textarea>

        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: '150px' }}>
            <label style={styles.label}>Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              style={styles.select}
            >
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>

          <div style={{ flex: 1, minWidth: '180px' }}>
            <label style={styles.label}>Due Date/Time</label>
            <input
              type="datetime-local"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              style={styles.input}
            />
          </div>
        </div>

        <button type="submit" style={styles.button}>Create Task</button>
      </form>

      <hr style={{ margin: '1.5rem 0' }} />

      {/* Task List */}
      <h2 style={{ marginBottom: '1rem' }}>Your Tasks</h2>
      {tasks.length === 0 ? (
        <p>No tasks found</p>
      ) : (
        <ul style={styles.list}>
          {tasks.map((t) => (
            <li key={t.id} style={styles.listItem}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <strong>{t.title}</strong>
                <span style={styles.statusBadge[t.status] || styles.statusBadge.default}>
                  {t.status}
                </span>
              </div>
              {t.description && <p style={{ marginTop: '0.25rem' }}>{t.description}</p>}
              <p style={{ fontSize: '0.85rem', marginTop: '0.25rem' }}>
                Contact ID: {t.contact_id} | Due: {formatDateTime(t.due_date)}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

const styles = {
  select: {
    padding: '0.4rem',
    borderRadius: '6px',
    border: '1px solid #4b5563',
    background: '#0f172a',
    color: 'white',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.6rem',
    maxWidth: '450px',
    marginBottom: '1.5rem',
  },
  input: {
    padding: '0.5rem',
    borderRadius: '6px',
    border: '1px solid #4b5563',
    background: '#0f172a',
    color: 'white',
  },
  textarea: {
    padding: '0.5rem',
    borderRadius: '6px',
    border: '1px solid #4b5563',
    background: '#0f172a',
    color: 'white',
    minHeight: '70px',
  },
  button: {
    padding: '0.6rem',
    background: '#3b82f6',
    border: 'none',
    borderRadius: '6px',
    color: 'white',
    cursor: 'pointer',
    marginTop: '0.5rem',
  },
  list: {
    listStyle: 'none',
    padding: 0,
  },
  listItem: {
    background: '#1e293b',
    padding: '0.75rem',
    borderRadius: '8px',
    marginBottom: '0.75rem',
  },
  label: {
    display: 'block',
    marginBottom: '0.25rem',
    fontSize: '0.85rem',
  },
  statusBadge: {
    pending: {
      padding: '0.15rem 0.5rem',
      borderRadius: '999px',
      background: '#fbbf24',
      color: '#111827',
      fontSize: '0.75rem',
      textTransform: 'capitalize',
    },
    in_progress: {
      padding: '0.15rem 0.5rem',
      borderRadius: '999px',
      background: '#38bdf8',
      color: '#0f172a',
      fontSize: '0.75rem',
      textTransform: 'capitalize',
    },
    completed: {
      padding: '0.15rem 0.5rem',
      borderRadius: '999px',
      background: '#22c55e',
      color: '#052e16',
      fontSize: '0.75rem',
      textTransform: 'capitalize',
    },
    default: {
      padding: '0.15rem 0.5rem',
      borderRadius: '999px',
      background: '#6b7280',
      color: '#f9fafb',
      fontSize: '0.75rem',
      textTransform: 'capitalize',
    },
  },
};
