import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { setAuthSession } from '../utils/auth';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('vishwa@example.com'); // default for testing
  const [password, setPassword] = useState('Password@123');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await axios.post('http://localhost:4000/api/auth/login', {
        email,
        password,
      });

      const { token, user } = res.data;
      // store token + setup 15 min expiry
      setAuthSession(token, 15);

      console.log('Logged in user:', user);
      navigate('/dashboard');
    } catch (err) {
      console.error(err);
      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else {
        setError('Something went wrong. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <form onSubmit={handleSubmit} style={styles.card}>
        <h2 style={styles.title}>SkillConnect Login</h2>

        {error && <div style={styles.error}>{error}</div>}

        <div style={styles.field}>
          <label style={styles.label}>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={styles.input}
            required
          />
        </div>

        <div style={styles.field}>
          <label style={styles.label}>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={styles.input}
            required
          />
        </div>

        <button type="submit" style={styles.button} disabled={loading}>
          {loading ? 'Logging in...' : 'Login'}
        </button>
      </form>
    </div>
  );
}

const styles = {
  container: {
    minHeight: '100vh',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: '#111827',
    color: '#e5e7eb',
  },
  card: {
    background: '#1f2937',
    padding: '2rem',
    borderRadius: '0.75rem',
    width: '100%',
    maxWidth: '400px',
    boxShadow: '0 10px 25px rgba(0,0,0,0.4)',
  },
  title: {
    marginBottom: '1.5rem',
    textAlign: 'center',
  },
  field: {
    marginBottom: '1rem',
  },
  label: {
    display: 'block',
    marginBottom: '0.25rem',
    fontSize: '0.9rem',
  },
  input: {
    width: '100%',
    padding: '0.5rem 0.75rem',
    borderRadius: '0.5rem',
    border: '1px solid #4b5563',
    background: '#111827',
    color: '#e5e7eb',
    outline: 'none',
  },
  button: {
    width: '100%',
    padding: '0.6rem 0.75rem',
    marginTop: '0.75rem',
    borderRadius: '0.5rem',
    border: 'none',
    background: '#3b82f6',
    color: '#f9fafb',
    fontWeight: '600',
    cursor: 'pointer',
  },
  error: {
    marginBottom: '1rem',
    padding: '0.5rem 0.75rem',
    borderRadius: '0.5rem',
    background: '#b91c1c',
    color: '#fee2e2',
    fontSize: '0.85rem',
  },
};
