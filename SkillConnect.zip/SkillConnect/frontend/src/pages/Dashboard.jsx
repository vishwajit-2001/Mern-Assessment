import { useEffect, useState } from 'react';
import client from '../api/axiosClient';

export default function Dashboard() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await client.get('/users');
        setUsers(res.data);
      } catch (err) {
        console.error('Error fetching users:', err);
        setError('Failed to load data from backend');
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  if (loading) return <p>Loading dashboard...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div>
      <h1 style={{ marginBottom: '1rem' }}>Dashboard</h1>
      <p style={{ marginBottom: '0.5rem' }}>
        Total users in system: <strong>{users.length}</strong>
      </p>
      {users.length > 0 && (
        <ul>
          {users.map((u) => (
            <li key={u.id}>
              {u.full_name} ({u.email})
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
