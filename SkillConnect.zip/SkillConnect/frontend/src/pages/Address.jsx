import { useEffect, useState } from 'react';
import client from '../api/axiosClient';

export default function Address() {
  const [contacts, setContacts] = useState([]);
  const [selectedContactId, setSelectedContactId] = useState('');
  const [addresses, setAddresses] = useState([]);

  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [pincode, setPincode] = useState('');
  const [country, setCountry] = useState('');

  const [loadingContacts, setLoadingContacts] = useState(true);
  const [loadingAddresses, setLoadingAddresses] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Load contacts on page load
  const loadContacts = async () => {
    try {
      const res = await client.get('/contacts');
      setContacts(res.data);
      if (res.data.length > 0) {
        setSelectedContactId(res.data[0].id.toString());
      }
    } catch (err) {
      console.error(err);
      setError('Failed to load contacts');
    } finally {
      setLoadingContacts(false);
    }
  };

  // Load addresses for selected contact
  const loadAddresses = async (contactId) => {
    if (!contactId) return;
    setLoadingAddresses(true);
    setError('');
    try {
      const res = await client.get(`/address/${contactId}`);
      setAddresses(res.data);
    } catch (err) {
      console.error(err);
      if (err.response?.status === 403) {
        setError('You do not own this contact');
      } else {
        setError('Failed to load addresses');
      }
      setAddresses([]);
    } finally {
      setLoadingAddresses(false);
    }
  };

  // on mount: fetch contacts
  useEffect(() => {
    loadContacts();
  }, []);

  // when selectedContactId changes: fetch addresses
  useEffect(() => {
    if (selectedContactId) {
      loadAddresses(selectedContactId);
    }
  }, [selectedContactId]);

  const handleAddAddress = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!selectedContactId) {
      setError('Please select a contact first');
      return;
    }
    if (!addressLine1) {
      setError('Address Line 1 is required');
      return;
    }

    try {
      await client.post('/address', {
        contact_id: Number(selectedContactId),
        address_line1: addressLine1,
        address_line2: addressLine2,
        city,
        state,
        pincode,
        country,
      });

      setSuccessMsg('Address added successfully!');
      // clear form
      setAddressLine1('');
      setAddressLine2('');
      setCity('');
      setState('');
      setPincode('');
      setCountry('');

      loadAddresses(selectedContactId);
    } catch (err) {
      console.error(err);
      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else {
        setError('Failed to add address');
      }
    }
  };

  if (loadingContacts) return <p>Loading contacts...</p>;

  return (
    <div>
      <h1 style={{ marginBottom: '1rem' }}>Address Management</h1>

      {error && <p style={{ color: 'red', marginBottom: '1rem' }}>{error}</p>}
      {successMsg && <p style={{ color: 'lightgreen', marginBottom: '1rem' }}>{successMsg}</p>}

      {/* Select contact */}
      <div style={{ marginBottom: '1.5rem' }}>
        <label style={{ marginRight: '0.5rem' }}>Select Contact:</label>
        <select
          value={selectedContactId}
          onChange={(e) => setSelectedContactId(e.target.value)}
          style={styles.select}
        >
          {contacts.length === 0 && <option value="">No contacts available</option>}
          {contacts.map((c) => (
            <option key={c.id} value={c.id}>
              {c.contact_number} {c.contact_email ? `(${c.contact_email})` : ''}
            </option>
          ))}
        </select>
      </div>

      {/* Add Address Form */}
      <form onSubmit={handleAddAddress} style={styles.form}>
        <input
          type="text"
          placeholder="Address Line 1"
          value={addressLine1}
          onChange={(e) => setAddressLine1(e.target.value)}
          style={styles.input}
          required
        />
        <input
          type="text"
          placeholder="Address Line 2"
          value={addressLine2}
          onChange={(e) => setAddressLine2(e.target.value)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="City"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="State"
          value={state}
          onChange={(e) => setState(e.target.value)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Pincode"
          value={pincode}
          onChange={(e) => setPincode(e.target.value)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Country"
          value={country}
          onChange={(e) => setCountry(e.target.value)}
          style={styles.input}
        />

        <button type="submit" style={styles.button}>Add Address</button>
      </form>

      <hr style={{ margin: '1.5rem 0' }} />

      {/* Address List */}
      <h2 style={{ marginBottom: '1rem' }}>Addresses for selected contact</h2>
      {loadingAddresses ? (
        <p>Loading addresses...</p>
      ) : addresses.length === 0 ? (
        <p>No addresses found for this contact</p>
      ) : (
        <ul style={styles.list}>
          {addresses.map((a) => (
            <li key={a.id} style={styles.listItem}>
              <strong>{a.address_line1}</strong>
              {a.address_line2 && <div>{a.address_line2}</div>}
              <div>
                {[a.city, a.state, a.pincode, a.country].filter(Boolean).join(', ')}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

const styles = {
  select: {
    padding: '0.4rem',
    borderRadius: '6px',
    border: '1px solid #4b5563',
    background: '#0f172a',
    color: 'white',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.6rem',
    maxWidth: '380px',
  },
  input: {
    padding: '0.5rem',
    borderRadius: '6px',
    border: '1px solid #4b5563',
    background: '#0f172a',
    color: 'white',
  },
  button: {
    padding: '0.6rem',
    background: '#22c55e',
    border: 'none',
    borderRadius: '6px',
    color: 'white',
    cursor: 'pointer',
    marginTop: '0.5rem',
  },
  list: {
    listStyle: 'none',
    padding: 0,
  },
  listItem: {
    background: '#1e293b',
    padding: '0.75rem',
    borderRadius: '8px',
    marginBottom: '0.75rem',
  },
};
