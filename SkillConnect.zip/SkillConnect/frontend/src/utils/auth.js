const TOKEN_KEY = 'token';
const EXPIRY_KEY = 'token_expiry';

let logoutTimerId = null;

export function clearAuthSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(EXPIRY_KEY);
  if (logoutTimerId) {
    clearTimeout(logoutTimerId);
    logoutTimerId = null;
  }
}

export function scheduleAutoLogout(expiryTimestamp) {
  if (logoutTimerId) {
    clearTimeout(logoutTimerId);
  }

  const remaining = expiryTimestamp - Date.now();

  if (remaining <= 0) {
    clearAuthSession();
    window.location.href = '/login';
    return;
  }

  logoutTimerId = setTimeout(() => {
    clearAuthSession();
    window.location.href = '/login';
  }, remaining);
}

export function setAuthSession(token, minutes = 15) {
  const expiry = Date.now() + minutes * 60 * 1000; // 15 minutes
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(EXPIRY_KEY, expiry.toString());
  scheduleAutoLogout(expiry);
}

export function getStoredToken() {
  const token = localStorage.getItem(TOKEN_KEY);
  const expiryStr = localStorage.getItem(EXPIRY_KEY);

  if (!token || !expiryStr) {
    return null;
  }

  const expiry = parseInt(expiryStr, 10);
  if (Date.now() > expiry) {
    // token already expired
    clearAuthSession();
    return null;
  }

  // still valid → schedule auto logout
  scheduleAutoLogout(expiry);
  return token;
}
