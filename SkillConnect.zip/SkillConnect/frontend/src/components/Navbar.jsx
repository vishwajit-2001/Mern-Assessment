import { Link, useNavigate } from 'react-router-dom';
import { clearAuthSession } from '../utils/auth';

export default function Navbar() {
  const navigate = useNavigate();

  const handleLogout = () => {
    clearAuthSession();
    navigate('/login');
  };

  return (
    <nav style={styles.nav}>
      <div style={styles.left}>SkillConnect</div>
      <div style={styles.links}>
        <Link to="/dashboard" style={styles.link}>Dashboard</Link>
        <Link to="/contacts" style={styles.link}>Contacts</Link>
        <Link to="/address" style={styles.link}>Address</Link>
        <Link to="/tasks" style={styles.link}>Tasks</Link>
        <button onClick={handleLogout} style={styles.logoutBtn}>
          Logout
        </button>
      </div>
    </nav>
  );
}

const styles = {
  nav: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0.75rem 1.5rem',
    background: '#111827',
    color: '#e5e7eb',
    borderBottom: '1px solid #374151',
  },
  left: {
    fontWeight: 700,
  },
  links: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
  },
  link: {
    color: '#e5e7eb',
    textDecoration: 'none',
    fontSize: '0.9rem',
  },
  logoutBtn: {
    padding: '0.4rem 0.75rem',
    borderRadius: '0.5rem',
    border: 'none',
    background: '#ef4444',
    color: '#f9fafb',
    cursor: 'pointer',
    fontSize: '0.85rem',
  },
};
