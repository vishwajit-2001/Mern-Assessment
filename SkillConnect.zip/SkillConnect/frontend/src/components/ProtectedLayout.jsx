import ProtectedRoute from './ProtectedRoute';
import Navbar from './Navbar';

export default function ProtectedLayout({ children }) {
  return (
    <ProtectedRoute>
      <div style={{ minHeight: '100vh', background: '#020617', color: '#e5e7eb' }}>
        <Navbar />
        <main style={{ padding: '1.5rem' }}>{children}</main>
      </div>
    </ProtectedRoute>
  );
}
