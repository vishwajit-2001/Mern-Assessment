import axios from 'axios';
import { getStoredToken } from '../utils/auth';

const client = axios.create({
  baseURL: 'http://localhost:4000/api',
});

client.interceptors.request.use((config) => {
  const token = getStoredToken(); // also schedules auto logout
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default client;
