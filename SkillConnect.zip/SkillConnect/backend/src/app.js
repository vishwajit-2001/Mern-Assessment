const express = require('express');
const cors = require('cors');

const userRoutes = require('./routes/userRoutes');
const authRoutes = require('./routes/authRoutes');
const contactRoutes = require('./routes/contactRoutes');
const app = express();

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'API is running 🚀' });
});

// auth routes
app.use('/api/auth', authRoutes);

// user routes
app.use('/api/users', userRoutes);

// contacts routes
app.use('/api/contacts', contactRoutes);

const addressRoutes = require('./routes/addressRoutes');

app.use('/api/address', addressRoutes);


const taskRoutes = require('./routes/taskRoutes');

app.use('/api/tasks', taskRoutes);


module.exports = app;
