import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Login from '../../frontend/src/pages/Login';
import Dashboard from '../../frontend/src/pages/Dashboard';
import Contacts from '../../frontend/src/pages/Contacts';
import Address from '../../frontend/src/pages/Address';
import Tasks from '../../frontend/src/pages/Tasks';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/contacts" element={<Contacts />} />
        <Route path="/address" element={<Address />} />
        <Route path="/tasks" element={<Tasks />} />

        {/* Default route */}
        <Route path="*" element={<Login />} />
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
