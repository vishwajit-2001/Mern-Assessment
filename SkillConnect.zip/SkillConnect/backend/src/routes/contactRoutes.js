const express = require('express');
const { createContact, getContacts } = require('../controllers/contactController');
const auth = require('../middleware/auth');

const router = express.Router();

// all contact routes need auth
router.post('/', auth, createContact);
router.get('/', auth, getContacts);

module.exports = router;
