const express = require('express');
const { getAllUsers } = require('../controllers/userController');
const auth = require('../middleware/auth');

const router = express.Router();

// all routes below need auth
router.get('/', auth, getAllUsers);

module.exports = router;
