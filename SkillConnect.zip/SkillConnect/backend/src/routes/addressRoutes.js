const express = require('express');
const { addAddress, getAddresses } = require('../controllers/addressController');
const auth = require('../middleware/auth');

const router = express.Router();

router.post('/', auth, addAddress);
router.get('/:contact_id', auth, getAddresses);

module.exports = router;
