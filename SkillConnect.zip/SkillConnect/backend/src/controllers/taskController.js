const pool = require('../config/db');
const { logEmail } = require('../utils/emailLogger');

// helper: verify contact belongs to this user
async function checkContactOwner(contact_id, user_id) {
  const [rows] = await pool.query(
    'SELECT id FROM users_contact WHERE id = ? AND user_id = ?',
    [contact_id, user_id]
  );
  return rows.length > 0;
}

// POST /api/tasks
async function createTask(req, res) {
  try {
    const userId = req.user.id;
    const { contact_id, title, description, status, due_date } = req.body;

    if (!contact_id || !title) {
      return res.status(400).json({ message: 'contact_id and title are required' });
    }

    // check if this contact belongs to the user
    const isOwner = await checkContactOwner(contact_id, userId);
    if (!isOwner) {
      return res.status(403).json({ message: 'This contact does not belong to you' });
    }

    // create task
    const [result] = await pool.query(
      `INSERT INTO users_task 
       (user_id, contact_id, title, description, status, due_date, created_by, updated_by)
       VALUES (?,?,?,?,?,?,?,?)`,
      [
        userId,
        contact_id,
        title,
        description || null,
        status || 'pending',
        due_date || null,
        userId,
        userId
      ]
    );

    // 🔔 send email notification (simulation)
    try {
      const [contactRows] = await pool.query(
        'SELECT contact_email FROM users_contact WHERE id = ?',
        [contact_id]
      );

      if (contactRows.length && contactRows[0].contact_email) {
        await logEmail(
          contactRows[0].contact_email,
          `New Task Assigned: ${title}`,
          `A new task has been created for you.\nTitle: ${title}\nDescription: ${description || ''}\nDue Date: ${due_date || 'N/A'}`
        );
      }
    } catch (emailErr) {
      console.error('Error sending task email notification:', emailErr);
      // don’t fail the whole request just because email failed
    }

    return res.status(201).json({
      id: result.insertId,
      user_id: userId,
      contact_id,
      title,
      description,
      status: status || 'pending',
      due_date
    });
  } catch (err) {
    console.error('Error creating task:', err);
    return res.status(500).json({ message: 'Server error' });
  }
}

// GET /api/tasks
async function getTasks(req, res) {
  try {
    const userId = req.user.id;

    const [rows] = await pool.query(
      `SELECT id, contact_id, title, description, status, due_date, created_at 
       FROM users_task WHERE user_id = ?`,
      [userId]
    );

    return res.json(rows);
  } catch (err) {
    console.error('Error fetching tasks:', err);
    return res.status(500).json({ message: 'Server error' });
  }
}

module.exports = { createTask, getTasks };
