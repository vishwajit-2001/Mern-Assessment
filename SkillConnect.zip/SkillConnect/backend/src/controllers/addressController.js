const pool = require('../config/db');

// helper: verify contact belongs to the user
async function checkContactOwner(contact_id, user_id) {
  const [rows] = await pool.query(
    'SELECT id FROM users_contact WHERE id = ? AND user_id = ?',
    [contact_id, user_id]
  );
  return rows.length > 0;
}

// POST /api/address
async function addAddress(req, res) {
  try {
    const userId = req.user.id;
    const {
      contact_id,
      address_line1,
      address_line2,
      city,
      state,
      pincode,
      country
    } = req.body;

    if (!contact_id || !address_line1) {
      return res.status(400).json({ message: 'contact_id and address_line1 are required' });
    }

    const isOwner = await checkContactOwner(contact_id, userId);
    if (!isOwner) {
      return res.status(403).json({ message: 'This contact does not belong to you' });
    }

    const [result] = await pool.query(
      `INSERT INTO contact_address 
        (contact_id, address_line1, address_line2, city, state, pincode, country, created_by, updated_by)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [
        contact_id,
        address_line1,
        address_line2 || null,
        city || null,
        state || null,
        pincode || null,
        country || null,
        userId,
        userId
      ]
    );

    res.status(201).json({
      id: result.insertId,
      contact_id,
      address_line1,
      address_line2,
      city,
      state,
      pincode,
      country
    });
  } catch (err) {
    console.error('Error adding address:', err);
    res.status(500).json({ message: 'Server error' });
  }
}

// GET /api/address/:contact_id
async function getAddresses(req, res) {
  try {
    const userId = req.user.id;
    const { contact_id } = req.params;

    const isOwner = await checkContactOwner(contact_id, userId);
    if (!isOwner) {
      return res.status(403).json({ message: 'You do not own this contact' });
    }

    const [rows] = await pool.query(
      `SELECT id, address_line1, address_line2, city, state, pincode, country, created_at 
       FROM contact_address WHERE contact_id = ?`,
      [contact_id]
    );

    res.json(rows);
  } catch (err) {
    console.error('Error fetching addresses:', err);
    res.status(500).json({ message: 'Server error' });
  }
}

module.exports = { addAddress, getAddresses };
