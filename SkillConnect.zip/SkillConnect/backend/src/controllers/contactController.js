const pool = require('../config/db');

// POST /api/contacts
async function createContact(req, res) {
  try {
    const userId = req.user.id; // from auth middleware
    const { contact_number, contact_email, note } = req.body;

    if (!contact_number) {
      return res.status(400).json({ message: 'contact_number is required' });
    }

    // optional: basic check like digits length
    if (!/^\d{10}$/.test(contact_number)) {
      return res.status(400).json({ message: 'contact_number must be 10 digits' });
    }

    const [result] = await pool.query(
      'INSERT INTO users_contact (user_id, contact_number, contact_email, note, created_by, updated_by) VALUES (?,?,?,?,?,?)',
      [userId, contact_number, contact_email || null, note || null, userId, userId]
    );

    return res.status(201).json({
      id: result.insertId,
      user_id: userId,
      contact_number,
      contact_email,
      note,
    });
  } catch (err) {
    console.error('Error creating contact:', err);

    // handle duplicate contact for same user
    if (err.code === 'ER_DUP_ENTRY') {
      return res
        .status(400)
        .json({ message: 'This contact_number already exists for this user' });
    }

    return res.status(500).json({ message: 'Server error' });
  }
}

// GET /api/contacts
async function getContacts(req, res) {
  try {
    const userId = req.user.id;

    const [rows] = await pool.query(
      'SELECT id, contact_number, contact_email, note, created_at FROM users_contact WHERE user_id = ?',
      [userId]
    );

    return res.json(rows);
  } catch (err) {
    console.error('Error fetching contacts:', err);
    return res.status(500).json({ message: 'Server error' });
  }
}

module.exports = { createContact, getContacts };
