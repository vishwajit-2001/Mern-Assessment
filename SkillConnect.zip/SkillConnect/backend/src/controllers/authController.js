const bcrypt = require('bcrypt');
const pool = require('../config/db');
const { generateToken } = require('../utils/token');

// POST /api/auth/register
async function register(req, res) {
  try {
    const { first_name, last_name, email, phone, password } = req.body;

    // basic validations
    if (!first_name || !last_name || !email || !phone || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    if (!/^\d{10}$/.test(phone)) {
      return res.status(400).json({ message: 'Phone must be 10 digits' });
    }

    // check if email or phone already exists
    const [existing] = await pool.query(
      'SELECT id FROM users WHERE email = ? OR phone = ?',
      [email, phone]
    );

    if (existing.length > 0) {
      return res.status(400).json({ message: 'Email or phone already in use' });
    }

    // hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // insert user
    const [result] = await pool.query(
      'INSERT INTO users (first_name, last_name, email, phone, password, created_by, updated_by) VALUES (?,?,?,?,?,?,?)',
      [first_name, last_name, email, phone, hashedPassword, null, null]
    );

    return res.status(201).json({
      id: result.insertId,
      email,
      message: 'User registered successfully',
    });
  } catch (err) {
    console.error('Error in register:', err);
    return res.status(500).json({ message: 'Server error' });
  }
}

// POST /api/auth/login
async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    // find user
    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);

    if (rows.length === 0) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    const user = rows[0];

    // compare password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    // generate token
    const token = generateToken(user);

    return res.json({
      token,
      user: {
        id: user.id,
        full_name: user.full_name,
        email: user.email,
        phone: user.phone,
      },
    });
  } catch (err) {
    console.error('Error in login:', err);
    return res.status(500).json({ message: 'Server error' });
  }
}

module.exports = { register, login };
