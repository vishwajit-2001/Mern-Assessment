const pool = require('../config/db');

// GET /api/users
async function getAllUsers(req, res) {
  try {
    const [rows] = await pool.query(
      'SELECT id, first_name, last_name, full_name, email, phone FROM users'
    );
    res.json(rows);
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({ message: 'Server error' });
  }
}

module.exports = { getAllUsers };
