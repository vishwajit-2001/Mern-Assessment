const jwt = require('jsonwebtoken');

function generateToken(user) {
  const payload = {
    id: user.id,
    email: user.email,
  };

  const expiresInMinutes = parseInt(process.env.TOKEN_EXPIRY_MINUTES || '15', 10);

  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: `${expiresInMinutes}m`,
  });
}

module.exports = { generateToken };
