const pool = require('../config/db');

async function logEmail(to_email, subject, body) {
  try {
    await pool.query(
      `INSERT INTO email_logs (to_email, subject, body) VALUES (?, ?, ?)`,
      [to_email, subject, body]
    );
  } catch (err) {
    console.error('Error logging email:', err);
  }
}

module.exports = { logEmail };
