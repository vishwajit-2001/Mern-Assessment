const pool = require('./config/db');

async function testConnection() {
  try {
    // simple query to check connection and fetch users
    const [rows] = await pool.query('SELECT id, full_name, email, phone FROM users');
    console.log('✅ DB connection successful!');
    console.log('Users rows:');
    console.log(rows);
    process.exit(0);
  } catch (err) {
    console.error('❌ DB connection failed:');
    console.error(err);
    process.exit(1);
  }
}

testConnection();
